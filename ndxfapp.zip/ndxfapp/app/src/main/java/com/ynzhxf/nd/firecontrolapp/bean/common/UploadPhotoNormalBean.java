package com.ynzhxf.nd.firecontrolapp.bean.common;


/**
 * author hbzhou
 * date 2019/4/1 16:37
 */
public class UploadPhotoNormalBean {

    private String localPath;
    private String uploadPath;

    public String getLocalPath() {
        return localPath;
    }

    public void setLocalPath(String localPath) {
        this.localPath = localPath;
    }

    public String getUploadPath() {
        return uploadPath;
    }

    public void setUploadPath(String uploadPath) {
        this.uploadPath = uploadPath;
    }
}
