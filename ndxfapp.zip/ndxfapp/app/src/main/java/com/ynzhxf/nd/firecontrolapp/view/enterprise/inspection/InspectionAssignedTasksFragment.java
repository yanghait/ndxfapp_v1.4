package com.ynzhxf.nd.firecontrolapp.view.enterprise.inspection;


/**
 * author hbzhou
 * date 2019/1/7 22:14
 */
public class InspectionAssignedTasksFragment extends InspectionItemFragment {

    @Override
    protected void initData() {

    }
}
