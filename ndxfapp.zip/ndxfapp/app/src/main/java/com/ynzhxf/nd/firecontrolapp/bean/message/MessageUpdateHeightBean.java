package com.ynzhxf.nd.firecontrolapp.bean.message;


/**
 * author hbzhou
 * date 2019/6/21 12:00
 */
public class MessageUpdateHeightBean {
    private int id;
    private int height;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }
}
