package com.ynzhxf.nd.firecontrolapp.view.enterprise;

public interface FileBottomClickCallBack {
    void onDownload();

    void onDelete();

    void onEditor();
}
