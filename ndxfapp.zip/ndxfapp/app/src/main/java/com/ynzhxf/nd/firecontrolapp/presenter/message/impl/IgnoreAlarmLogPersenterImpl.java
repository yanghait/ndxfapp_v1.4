package com.ynzhxf.nd.firecontrolapp.presenter.message.impl;

import com.ynzhxf.nd.firecontrolapp.bean.ResultBean;
import com.ynzhxf.nd.firecontrolapp.bean.nodebase.AlarmLogBean;
import com.ynzhxf.nd.firecontrolapp.model.message.MessageModelFactory;
import com.ynzhxf.nd.firecontrolapp.presenter.BasePersenter;
import com.ynzhxf.nd.firecontrolapp.presenter.message.IIgnoreAlarmLogPersenter;

/**
 * Created by nd on 2018-08-02.
 */

class IgnoreAlarmLogPersenterImpl extends BasePersenter implements IIgnoreAlarmLogPersenter {
    private IIgnoreAlarmLogView view;
    private IIgnoreAlarmLogModel model;


    public IgnoreAlarmLogPersenterImpl(IIgnoreAlarmLogView view){
        this.view = view;
        this.model = MessageModelFactory.getIgnoreAlarmLogModel(this);
    }
    @Override
    public void callBackError(ResultBean<String, String> result, String action) {
        if(view != null){
            view.callBackError(result ,action);
        }
    }

    @Override
    public void detachView() {
        view = null;
    }

    @Override
    public void doIgnoreAlarmLog(String ID) {
        model.requestIgnoreAlarmLog(ID);
    }

    @Override
    public void callBackIgnoreAlarmLog(ResultBean<AlarmLogBean, String> result) {
        if(view != null){
            view.callBackIgnoreAlarmLog(result);
        }
    }
}
