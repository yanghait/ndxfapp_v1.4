package com.ynzhxf.nd.firecontrolapp.view.enterprise.owner.adapter;

import android.view.View;

public interface TabAdapter {
    public View getView(int position);
}
