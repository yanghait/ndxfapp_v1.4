package com.ynzhxf.nd.firecontrolapp.bean.share;

public class OperationalPlanFileBean {

    /**
     * F_OperationPlanID : 7a582b39c4064309b27aa2ab009a0793
     * OpeationPlanMain : null
     * F_FileName : 58x58.png
     * F_FileType : .png
     * F_Extension : .png
     * F_Url : /Uploads/OperationalPlanFile/7786e210d8b94aa59dd927ebe1781d01.png
     * F_FileSize : 4343
     * F_DelState : 0
     * UserID : 473da00c69ce4bafbc0b3e8568950402
     * ID : 7786e210d8b94aa59dd927ebe1781d01
     * IsNew : true
     */

    private String F_OperationPlanID;
    private Object OpeationPlanMain;
    private String F_FileName;
    private String F_FileType;
    private String F_Extension;
    private String F_Url;
    private int F_FileSize;
    private int F_DelState;
    private String UserID;
    private String ID;
    private boolean IsNew;

    public String getF_OperationPlanID() {
        return F_OperationPlanID;
    }

    public void setF_OperationPlanID(String F_OperationPlanID) {
        this.F_OperationPlanID = F_OperationPlanID;
    }

    public Object getOpeationPlanMain() {
        return OpeationPlanMain;
    }

    public void setOpeationPlanMain(Object OpeationPlanMain) {
        this.OpeationPlanMain = OpeationPlanMain;
    }

    public String getF_FileName() {
        return F_FileName;
    }

    public void setF_FileName(String F_FileName) {
        this.F_FileName = F_FileName;
    }

    public String getF_FileType() {
        return F_FileType;
    }

    public void setF_FileType(String F_FileType) {
        this.F_FileType = F_FileType;
    }

    public String getF_Extension() {
        return F_Extension;
    }

    public void setF_Extension(String F_Extension) {
        this.F_Extension = F_Extension;
    }

    public String getF_Url() {
        return F_Url;
    }

    public void setF_Url(String F_Url) {
        this.F_Url = F_Url;
    }

    public int getF_FileSize() {
        return F_FileSize;
    }

    public void setF_FileSize(int F_FileSize) {
        this.F_FileSize = F_FileSize;
    }

    public int getF_DelState() {
        return F_DelState;
    }

    public void setF_DelState(int F_DelState) {
        this.F_DelState = F_DelState;
    }

    public String getUserID() {
        return UserID;
    }

    public void setUserID(String UserID) {
        this.UserID = UserID;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public boolean isIsNew() {
        return IsNew;
    }

    public void setIsNew(boolean IsNew) {
        this.IsNew = IsNew;
    }
}
