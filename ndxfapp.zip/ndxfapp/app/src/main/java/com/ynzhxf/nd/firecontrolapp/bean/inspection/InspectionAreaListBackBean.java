package com.ynzhxf.nd.firecontrolapp.bean.inspection;

public class InspectionAreaListBackBean {

    /**
     * ID : d0ccbb9bf000447f85c423d228496657
     * Name : 区域A
     * ProjectId : 3a425cb5c4d14cd399c8b5d54d0e2d52
     * ProjectName : null
     * InspectItemIds : null
     * Remark : null
     * InspectorId : 909c7188f67542f2b1ce45666bcf1c22
     * InspectorName : test132
     * InspectorPhone : null
     * InspectorShow : test132()
     */

    private String ID;
    private String Name;
    private String ProjectId;
    private Object ProjectName;
    private Object InspectItemIds;
    private Object Remark;
    private String InspectorId;
    private String InspectorName;
    private Object InspectorPhone;
    private String InspectorShow;

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getProjectId() {
        return ProjectId;
    }

    public void setProjectId(String ProjectId) {
        this.ProjectId = ProjectId;
    }

    public Object getProjectName() {
        return ProjectName;
    }

    public void setProjectName(Object ProjectName) {
        this.ProjectName = ProjectName;
    }

    public Object getInspectItemIds() {
        return InspectItemIds;
    }

    public void setInspectItemIds(Object InspectItemIds) {
        this.InspectItemIds = InspectItemIds;
    }

    public Object getRemark() {
        return Remark;
    }

    public void setRemark(Object Remark) {
        this.Remark = Remark;
    }

    public String getInspectorId() {
        return InspectorId;
    }

    public void setInspectorId(String InspectorId) {
        this.InspectorId = InspectorId;
    }

    public String getInspectorName() {
        return InspectorName;
    }

    public void setInspectorName(String InspectorName) {
        this.InspectorName = InspectorName;
    }

    public Object getInspectorPhone() {
        return InspectorPhone;
    }

    public void setInspectorPhone(Object InspectorPhone) {
        this.InspectorPhone = InspectorPhone;
    }

    public String getInspectorShow() {
        return InspectorShow;
    }

    public void setInspectorShow(String InspectorShow) {
        this.InspectorShow = InspectorShow;
    }
}
