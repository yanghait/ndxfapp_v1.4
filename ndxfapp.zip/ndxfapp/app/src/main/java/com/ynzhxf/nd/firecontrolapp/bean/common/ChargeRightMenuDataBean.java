package com.ynzhxf.nd.firecontrolapp.bean.common;


/**
 * author hbzhou
 * date 2019/6/3 11:07
 */
public class ChargeRightMenuDataBean {

    private String mRightData;
    private boolean mSelectFlag;

    public String getmRightData() {
        return mRightData;
    }

    public void setmRightData(String mRightData) {
        this.mRightData = mRightData;
    }

    public boolean ismSelectFlag() {
        return mSelectFlag;
    }

    public void setmSelectFlag(boolean mSelectFlag) {
        this.mSelectFlag = mSelectFlag;
    }
}
