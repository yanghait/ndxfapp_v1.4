package com.ynzhxf.nd.firecontrolapp.bean.share;

public class FileShareMyFileBean {

    /**
     * F_Classification : 0
     * F_DelState : 0
     * ID : f776671ab4f74fc99a8c640331ba3fc4
     * F_FileName : BUG测试报告板.docx
     * F_FileTypeID : 31db8bddcba6422eb699e678cebc4b40
     * F_FileUrl : /Uploads/FireShare/94b6970a772448cea351e438d4e9487e/f776671ab4f74fc99a8c640331ba3fc4.docx
     * F_Remark : null
     * F_Title : BUG测试报告模板
     * F_ProjectID : 94b6970a772448cea351e438d4e9487e
     * F_UploadDate : 2018-10-29 15:57:02
     * F_UploadUserID : c7ce437b024e4b82bb38ed488f1216c2
     * UserName : 赵永志
     * TypeNmae : 文档
     * ProjectName : 云南捷诺科技
     */

    private String F_Classification;
    private int F_DelState;
    private String ID;
    private String F_FileName;
    private String F_FileTypeID;
    private String F_FileUrl;
    private Object F_Remark;
    private String F_Title;
    private String F_ProjectID;
    private String F_UploadDate;
    private String F_UploadUserID;
    private String UserName;
    private String TypeNmae;
    private String ProjectName;

    public String getF_Classification() {
        return F_Classification;
    }

    public void setF_Classification(String F_Classification) {
        this.F_Classification = F_Classification;
    }

    public int getF_DelState() {
        return F_DelState;
    }

    public void setF_DelState(int F_DelState) {
        this.F_DelState = F_DelState;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getF_FileName() {
        return F_FileName;
    }

    public void setF_FileName(String F_FileName) {
        this.F_FileName = F_FileName;
    }

    public String getF_FileTypeID() {
        return F_FileTypeID;
    }

    public void setF_FileTypeID(String F_FileTypeID) {
        this.F_FileTypeID = F_FileTypeID;
    }

    public String getF_FileUrl() {
        return F_FileUrl;
    }

    public void setF_FileUrl(String F_FileUrl) {
        this.F_FileUrl = F_FileUrl;
    }

    public Object getF_Remark() {
        return F_Remark;
    }

    public void setF_Remark(Object F_Remark) {
        this.F_Remark = F_Remark;
    }

    public String getF_Title() {
        return F_Title;
    }

    public void setF_Title(String F_Title) {
        this.F_Title = F_Title;
    }

    public String getF_ProjectID() {
        return F_ProjectID;
    }

    public void setF_ProjectID(String F_ProjectID) {
        this.F_ProjectID = F_ProjectID;
    }

    public String getF_UploadDate() {
        return F_UploadDate;
    }

    public void setF_UploadDate(String F_UploadDate) {
        this.F_UploadDate = F_UploadDate;
    }

    public String getF_UploadUserID() {
        return F_UploadUserID;
    }

    public void setF_UploadUserID(String F_UploadUserID) {
        this.F_UploadUserID = F_UploadUserID;
    }

    public String getUserName() {
        return UserName;
    }

    public void setUserName(String UserName) {
        this.UserName = UserName;
    }

    public String getTypeNmae() {
        return TypeNmae;
    }

    public void setTypeNmae(String TypeNmae) {
        this.TypeNmae = TypeNmae;
    }

    public String getProjectName() {
        return ProjectName;
    }

    public void setProjectName(String ProjectName) {
        this.ProjectName = ProjectName;
    }
}
