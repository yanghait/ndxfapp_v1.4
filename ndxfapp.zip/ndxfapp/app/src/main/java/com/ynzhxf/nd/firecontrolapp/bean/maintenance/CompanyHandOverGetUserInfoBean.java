package com.ynzhxf.nd.firecontrolapp.bean.maintenance;

public class CompanyHandOverGetUserInfoBean {

    /**
     * UserName : 666666
     * Password : 666666
     * ConfirmPassword : null
     * ProjectRoleTypeID : 2
     * UserOrgainzationType : 4
     * Name : 测试维保公司管理员
     * OrganizationID : 671d9b238ehj406fyyc86399256539582
     * RoleID : null
     * Role : null
     * Phone : null
     * ContactsPhone : 1111
     * Addr : 111
     * Occupation : 1
     * IsReceivePushMsgAlert : true
     * IdCard : null
     * Sex : null
     * IsLock : false
     * Remark : null
     * InPutTime : null
     * QueryKey : null
     * ID : 0ed6e573e8a840e098420a73ce1e403d
     * IsNew : true
     */

    private String UserName;
    private String Password;
    private Object ConfirmPassword;
    private String ProjectRoleTypeID;
    private String UserOrgainzationType;
    private String Name;
    private String OrganizationID;
    private Object RoleID;
    private Object Role;
    private Object Phone;
    private String ContactsPhone;
    private String Addr;
    private String Occupation;
    private boolean IsReceivePushMsgAlert;
    private Object IdCard;
    private Object Sex;
    private boolean IsLock;
    private Object Remark;
    private Object InPutTime;
    private Object QueryKey;
    private String ID;
    private boolean IsNew;

    public String getUserName() {
        return UserName;
    }

    public void setUserName(String UserName) {
        this.UserName = UserName;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    public Object getConfirmPassword() {
        return ConfirmPassword;
    }

    public void setConfirmPassword(Object ConfirmPassword) {
        this.ConfirmPassword = ConfirmPassword;
    }

    public String getProjectRoleTypeID() {
        return ProjectRoleTypeID;
    }

    public void setProjectRoleTypeID(String ProjectRoleTypeID) {
        this.ProjectRoleTypeID = ProjectRoleTypeID;
    }

    public String getUserOrgainzationType() {
        return UserOrgainzationType;
    }

    public void setUserOrgainzationType(String UserOrgainzationType) {
        this.UserOrgainzationType = UserOrgainzationType;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getOrganizationID() {
        return OrganizationID;
    }

    public void setOrganizationID(String OrganizationID) {
        this.OrganizationID = OrganizationID;
    }

    public Object getRoleID() {
        return RoleID;
    }

    public void setRoleID(Object RoleID) {
        this.RoleID = RoleID;
    }

    public Object getRole() {
        return Role;
    }

    public void setRole(Object Role) {
        this.Role = Role;
    }

    public Object getPhone() {
        return Phone;
    }

    public void setPhone(Object Phone) {
        this.Phone = Phone;
    }

    public String getContactsPhone() {
        return ContactsPhone;
    }

    public void setContactsPhone(String ContactsPhone) {
        this.ContactsPhone = ContactsPhone;
    }

    public String getAddr() {
        return Addr;
    }

    public void setAddr(String Addr) {
        this.Addr = Addr;
    }

    public String getOccupation() {
        return Occupation;
    }

    public void setOccupation(String Occupation) {
        this.Occupation = Occupation;
    }

    public boolean isIsReceivePushMsgAlert() {
        return IsReceivePushMsgAlert;
    }

    public void setIsReceivePushMsgAlert(boolean IsReceivePushMsgAlert) {
        this.IsReceivePushMsgAlert = IsReceivePushMsgAlert;
    }

    public Object getIdCard() {
        return IdCard;
    }

    public void setIdCard(Object IdCard) {
        this.IdCard = IdCard;
    }

    public Object getSex() {
        return Sex;
    }

    public void setSex(Object Sex) {
        this.Sex = Sex;
    }

    public boolean isIsLock() {
        return IsLock;
    }

    public void setIsLock(boolean IsLock) {
        this.IsLock = IsLock;
    }

    public Object getRemark() {
        return Remark;
    }

    public void setRemark(Object Remark) {
        this.Remark = Remark;
    }

    public Object getInPutTime() {
        return InPutTime;
    }

    public void setInPutTime(Object InPutTime) {
        this.InPutTime = InPutTime;
    }

    public Object getQueryKey() {
        return QueryKey;
    }

    public void setQueryKey(Object QueryKey) {
        this.QueryKey = QueryKey;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public boolean isIsNew() {
        return IsNew;
    }

    public void setIsNew(boolean IsNew) {
        this.IsNew = IsNew;
    }
}
