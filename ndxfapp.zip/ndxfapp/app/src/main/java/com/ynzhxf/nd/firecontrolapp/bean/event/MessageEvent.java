package com.ynzhxf.nd.firecontrolapp.bean.event;


/**
 * author hbzhou
 * date 2019/2/25 09:20
 */
public class MessageEvent {
}
