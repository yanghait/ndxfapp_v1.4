package com.ynzhxf.nd.firecontrolapp.bean.maintenance;

public class OwnerImpowerInputBean {
    private String Token;
    private String projectID;

    public String getToken() {
        return Token;
    }

    public void setToken(String token) {
        Token = token;
    }

    public String getProjectID() {
        return projectID;
    }

    public void setProjectID(String projectID) {
        this.projectID = projectID;
    }
}
