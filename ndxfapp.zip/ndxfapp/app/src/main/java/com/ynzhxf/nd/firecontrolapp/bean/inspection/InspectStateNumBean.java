package com.ynzhxf.nd.firecontrolapp.bean.inspection;


/**
 * author hbzhou
 * date 2019/4/4 13:02
 */
public class InspectStateNumBean {

    /**
     * InspectTaskState : -1
     * Count : 93
     */

    private int InspectTaskState;
    private int Count;

    public int getInspectTaskState() {
        return InspectTaskState;
    }

    public void setInspectTaskState(int InspectTaskState) {
        this.InspectTaskState = InspectTaskState;
    }

    public int getCount() {
        return Count;
    }

    public void setCount(int Count) {
        this.Count = Count;
    }
}
