package com.ynzhxf.nd.firecontrolapp.bean.charge;


/**
 * author hbzhou
 * date 2019/11/19 11:50
 */
public class ChargeExtraContentBean {
    private int level;

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }
}
