package com.ynzhxf.nd.firecontrolapp.view.enterprise.owner.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.blankj.utilcode.util.SPUtils;
import com.blankj.utilcode.util.StringUtils;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.ynzhxf.nd.firecontrolapp.R;
import com.ynzhxf.nd.firecontrolapp.adapter.baserecycleradapter.CommonAdapter;
import com.ynzhxf.nd.firecontrolapp.adapter.baserecycleradapter.SpecialCommonAdapter;
import com.ynzhxf.nd.firecontrolapp.bean.ResultBean;
import com.ynzhxf.nd.firecontrolapp.bean.maintenance.MaintenListAllBean;
import com.ynzhxf.nd.firecontrolapp.bean.maintenance.MaintenListBackBean;
import com.ynzhxf.nd.firecontrolapp.bean.maintenance.MaintenanceListInfoBean;
import com.ynzhxf.nd.firecontrolapp.presenter.maintenance.IMaintenanceListPresenter;
import com.ynzhxf.nd.firecontrolapp.presenter.maintenance.impl.MaintenManagePresenterFactory;
import com.ynzhxf.nd.firecontrolapp.ui.MyLoadHeader;
import com.ynzhxf.nd.firecontrolapp.ui.MyLoadMenuBackHeader;
import com.ynzhxf.nd.firecontrolapp.ui.NormalDividerItemDecoration;
import com.ynzhxf.nd.firecontrolapp.util.HelperTool;
import com.ynzhxf.nd.firecontrolapp.util.LogUtils;
import com.ynzhxf.nd.firecontrolapp.view.HelperView;
import com.ynzhxf.nd.firecontrolapp.view.basenode.MaintenanceManageActivity;
import com.ynzhxf.nd.firecontrolapp.view.fragment.BaseFragment;

import java.util.ArrayList;
import java.util.List;

/**
 * 业主我的工单列表fragment
 */
public class OwnerMyOrderListFragment extends BaseFragment implements IMaintenanceListPresenter.IMaintenanceListView {

    public RefreshLayout refreshLayout;

    public RecyclerView recyclerView;

    private IMaintenanceListPresenter presenter;

    private int pageIndex = 1;

    final List<MaintenListBackBean> beanList = new ArrayList<>();

    private MaintenanceListInfoBean bean;

    public String state;
    protected String projectId;

    public boolean isCompany = false;

    public LinearLayout mNoDataView;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_owner_my_order, null);
        refreshLayout = view.findViewById(R.id.owner_my_order_refreshLayout);
        recyclerView = view.findViewById(R.id.owner_mt_order_rv_list);

        mNoDataView = view.findViewById(R.id.all_no_data);

        MyLoadMenuBackHeader myLoadHeader = new MyLoadMenuBackHeader(getActivity());
        refreshLayout.setRefreshHeader(myLoadHeader);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        NormalDividerItemDecoration div = new NormalDividerItemDecoration(getActivity(), DividerItemDecoration.VERTICAL);
        div.setDrawable(getResources().getDrawable(R.drawable.divider_shape));
        recyclerView.addItemDecoration(div);
        recyclerView.setLayoutManager(linearLayoutManager);
        return view;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getArguments();
        if (bundle != null) {
            state = bundle.getString("state");
            projectId = bundle.getString("projectId");
        }
    }

    public static OwnerMyOrderListFragment newInstance(String state, String projectId) {
        Bundle args = new Bundle();
        args.putString("state", state);
        args.putString("projectId", projectId);
        OwnerMyOrderListFragment fragment = new OwnerMyOrderListFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        presenter = MaintenManagePresenterFactory.getOwnerListPersenterImpl(this);
        addPersenter(presenter);
        bean = new MaintenanceListInfoBean();
        bean.setToken(HelperTool.getToken());
        bean.setState(state);
        bean.setProjectId(projectId);

        String start_Time = SPUtils.getInstance().getString("start_Time");
        String end_Time = SPUtils.getInstance().getString("end_Time");

        if (!StringUtils.isEmpty(start_Time) && !StringUtils.isEmpty(end_Time)) {
            bean.setStartTime(start_Time);
            bean.setEndTime(end_Time);
        }

        pageIndex = 1;
        bean.setPageIndex(String.valueOf(pageIndex));
        bean.setPageSize("10");
        LogUtils.showLoge("输出bean1111---" + state, bean.toString());
        beanList.clear();

        if (!isCompany) {
            presenter.doMaintenanceList(bean);
        }

        refreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                bean.setPageIndex("1");
                pageIndex = 1;
                if (beanList.size() > 0) {
                    beanList.clear();
                }
                presenter.doMaintenanceList(bean);
                refreshLayout.finishRefresh(2000);
            }
        });

        refreshLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                pageIndex++;
                bean.setPageIndex(String.valueOf(pageIndex));
                presenter.doMaintenanceList(bean);
                refreshLayout.finishLoadMore();
            }
        });
    }

    @Override
    public void callBackMaintenanceList(ResultBean<MaintenListAllBean, String> resultBean) {
        if (resultBean == null || resultBean.getData() == null || resultBean.getData().getRows() == null || resultBean.getData().getRows().size() == 0) {
            if (beanList.size() == 0) {
                mNoDataView.setVisibility(View.VISIBLE);
            }
            return;
        } else {
            mNoDataView.setVisibility(View.GONE);
        }

        //LogUtils.showLoge("输出获取到的工单数量787800---",resultBean.getData().getRows().size()+"~~~~~");

        beanList.addAll(resultBean.getData().getRows());
        SpecialCommonAdapter adapter = MaintenanceManageActivity.initWorkOrderList(recyclerView, getActivity(), beanList);
        adapter.notifyDataSetChanged();
    }

}
