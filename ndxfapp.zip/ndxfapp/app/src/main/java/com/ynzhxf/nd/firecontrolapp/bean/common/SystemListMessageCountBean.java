package com.ynzhxf.nd.firecontrolapp.bean.common;


/**
 * author hbzhou
 * date 2019/1/29 14:27
 */
public class SystemListMessageCountBean {

    /**
     * totalCount : 17
     * AlarmCount : 0
     * ID : 924c8ed1a5954c51a7138cade2963537
     */

    private String totalCount;
    private String AlarmCount;
    private String ID;

    public String getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(String totalCount) {
        this.totalCount = totalCount;
    }

    public String getAlarmCount() {
        return AlarmCount;
    }

    public void setAlarmCount(String AlarmCount) {
        this.AlarmCount = AlarmCount;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }
}
