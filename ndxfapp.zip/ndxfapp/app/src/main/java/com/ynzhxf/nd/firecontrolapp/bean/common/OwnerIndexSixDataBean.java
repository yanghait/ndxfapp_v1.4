package com.ynzhxf.nd.firecontrolapp.bean.common;


/**
 * author hbzhou
 * date 2019/6/19 11:31
 */
public class OwnerIndexSixDataBean {

    /**
     * ProjectId : 3a425cb5c4d14cd399c8b5d54d0e2d52
     * ProjectName : 官房大酒店
     * ProjectRepairTimes : 0
     * FireRiskLevel : 0
     * RealAlarmCount : 0
     * Recent24HourCount : 0
     * WorkOrderSum : 8
     * InspectionTaskSum : 1
     */

    private String ProjectId;
    private String ProjectName;
    private String ProjectRepairTimes;
    private String FireRiskLevel;
    private String RealAlarmCount;
    private String Recent24HourCount;
    private String WorkOrderSum;
    private String InspectionTaskSum;

    public String getProjectId() {
        return ProjectId;
    }

    public void setProjectId(String ProjectId) {
        this.ProjectId = ProjectId;
    }

    public String getProjectName() {
        return ProjectName;
    }

    public void setProjectName(String ProjectName) {
        this.ProjectName = ProjectName;
    }

    public String getProjectRepairTimes() {
        return ProjectRepairTimes;
    }

    public void setProjectRepairTimes(String ProjectRepairTimes) {
        this.ProjectRepairTimes = ProjectRepairTimes;
    }

    public String getFireRiskLevel() {
        return FireRiskLevel;
    }

    public void setFireRiskLevel(String FireRiskLevel) {
        this.FireRiskLevel = FireRiskLevel;
    }

    public String getRealAlarmCount() {
        return RealAlarmCount;
    }

    public void setRealAlarmCount(String RealAlarmCount) {
        this.RealAlarmCount = RealAlarmCount;
    }

    public String getRecent24HourCount() {
        return Recent24HourCount;
    }

    public void setRecent24HourCount(String Recent24HourCount) {
        this.Recent24HourCount = Recent24HourCount;
    }

    public String getWorkOrderSum() {
        return WorkOrderSum;
    }

    public void setWorkOrderSum(String WorkOrderSum) {
        this.WorkOrderSum = WorkOrderSum;
    }

    public String getInspectionTaskSum() {
        return InspectionTaskSum;
    }

    public void setInspectionTaskSum(String InspectionTaskSum) {
        this.InspectionTaskSum = InspectionTaskSum;
    }
}
