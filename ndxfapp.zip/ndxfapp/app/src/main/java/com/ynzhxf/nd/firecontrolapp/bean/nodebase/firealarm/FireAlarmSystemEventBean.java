package com.ynzhxf.nd.firecontrolapp.bean.nodebase.firealarm;


/**
 * author hbzhou
 * date 2019/1/15 10:32
 */
public class FireAlarmSystemEventBean {
    private String ID;
    private String num;
    private String name;
    private String content;
    private String type;

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
