package com.ynzhxf.nd.firecontrolapp.presenter;

/**
 * 基础桥梁
 * Created by nd on 2018-07-23.
 */

public abstract class BasePersenter implements IBasePersenter {

}
