package com.ynzhxf.nd.firecontrolapp.bean.inspection;

public class InspectionSetPersonBackBean {

    /**
     * UserName : test124
     * Password : 123456
     * ConfirmPassword : null
     * ProjectRoleTypeID : 2
     * UserOrgainzationType : 3
     * Name : 测试5
     * OrganizationID : 6e9f2efbaa1d40a29400d0e03c8bec5f
     * RoleID : null
     * Role : null
     * Phone : null
     * ContactsPhone : null
     * Addr : null
     * Occupation : 123456
     * IsReceivePushMsgAlert : true
     * IdCard : null
     * Sex : 0
     * IsLock : false
     * Remark : null
     * InPutTime : /Date(1545183973773)/
     * QueryKey : null
     * ID : 4e49ae2dd5b7424ca71affaaafb9629b
     * IsNew : true
     */

    private String UserName;
    private String Password;
    private Object ConfirmPassword;
    private String ProjectRoleTypeID;
    private String UserOrgainzationType;
    private String Name;
    private String OrganizationID;
    private Object RoleID;
    private Object Role;
    private Object Phone;
    private String ContactsPhone;
    private Object Addr;
    private String Occupation;
    private boolean IsReceivePushMsgAlert;
    private Object IdCard;
    private int Sex;
    private boolean IsLock;
    private Object Remark;
    private String InPutTime;
    private Object QueryKey;
    private String ID;
    private boolean IsNew;

    public String getUserName() {
        return UserName;
    }

    public void setUserName(String UserName) {
        this.UserName = UserName;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    public Object getConfirmPassword() {
        return ConfirmPassword;
    }

    public void setConfirmPassword(Object ConfirmPassword) {
        this.ConfirmPassword = ConfirmPassword;
    }

    public String getProjectRoleTypeID() {
        return ProjectRoleTypeID;
    }

    public void setProjectRoleTypeID(String ProjectRoleTypeID) {
        this.ProjectRoleTypeID = ProjectRoleTypeID;
    }

    public String getUserOrgainzationType() {
        return UserOrgainzationType;
    }

    public void setUserOrgainzationType(String UserOrgainzationType) {
        this.UserOrgainzationType = UserOrgainzationType;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getOrganizationID() {
        return OrganizationID;
    }

    public void setOrganizationID(String OrganizationID) {
        this.OrganizationID = OrganizationID;
    }

    public Object getRoleID() {
        return RoleID;
    }

    public void setRoleID(Object RoleID) {
        this.RoleID = RoleID;
    }

    public Object getRole() {
        return Role;
    }

    public void setRole(Object Role) {
        this.Role = Role;
    }

    public Object getPhone() {
        return Phone;
    }

    public void setPhone(Object Phone) {
        this.Phone = Phone;
    }

    public String getContactsPhone() {
        return ContactsPhone;
    }

    public void setContactsPhone(String ContactsPhone) {
        this.ContactsPhone = ContactsPhone;
    }

    public Object getAddr() {
        return Addr;
    }

    public void setAddr(Object Addr) {
        this.Addr = Addr;
    }

    public String getOccupation() {
        return Occupation;
    }

    public void setOccupation(String Occupation) {
        this.Occupation = Occupation;
    }

    public boolean isIsReceivePushMsgAlert() {
        return IsReceivePushMsgAlert;
    }

    public void setIsReceivePushMsgAlert(boolean IsReceivePushMsgAlert) {
        this.IsReceivePushMsgAlert = IsReceivePushMsgAlert;
    }

    public Object getIdCard() {
        return IdCard;
    }

    public void setIdCard(Object IdCard) {
        this.IdCard = IdCard;
    }

    public int getSex() {
        return Sex;
    }

    public void setSex(int Sex) {
        this.Sex = Sex;
    }

    public boolean isIsLock() {
        return IsLock;
    }

    public void setIsLock(boolean IsLock) {
        this.IsLock = IsLock;
    }

    public Object getRemark() {
        return Remark;
    }

    public void setRemark(Object Remark) {
        this.Remark = Remark;
    }

    public String getInPutTime() {
        return InPutTime;
    }

    public void setInPutTime(String InPutTime) {
        this.InPutTime = InPutTime;
    }

    public Object getQueryKey() {
        return QueryKey;
    }

    public void setQueryKey(Object QueryKey) {
        this.QueryKey = QueryKey;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public boolean isIsNew() {
        return IsNew;
    }

    public void setIsNew(boolean IsNew) {
        this.IsNew = IsNew;
    }
}
