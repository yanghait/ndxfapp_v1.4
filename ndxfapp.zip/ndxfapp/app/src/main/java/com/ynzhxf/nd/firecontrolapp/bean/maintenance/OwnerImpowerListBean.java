package com.ynzhxf.nd.firecontrolapp.bean.maintenance;

import com.ynzhxf.nd.firecontrolapp.bean.BaseDataBean;

public class OwnerImpowerListBean extends BaseDataBean {
    /**
     * ID : c89efef0f71d447d8c84cfdf76616668
     * ProjectSystemName : 消防给水系统
     */

    private String ProjectSystemName;

    public String getProjectSystemName() {
        return ProjectSystemName;
    }

    public void setProjectSystemName(String ProjectSystemName) {
        this.ProjectSystemName = ProjectSystemName;
    }

}
